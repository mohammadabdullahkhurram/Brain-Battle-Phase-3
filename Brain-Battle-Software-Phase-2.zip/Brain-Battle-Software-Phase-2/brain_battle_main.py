import os
os.environ["QT_MEDIA_BACKEND"] = "ffmpeg"
os.environ["QT_FFMPEG_DISABLE_HW_DECODING"] = "1"

from pathlib import Path
import sys
import tempfile
import datetime as _dt

import numpy as _np
import vlc

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QTabWidget,
    QVBoxLayout, QHBoxLayout, QGridLayout, QLabel,
    QPushButton, QFrame, QSizePolicy, QFileDialog,
    QListWidget, QListWidgetItem, QScrollArea,
    QSplitter, QSlider, QComboBox, QLineEdit,
    QGroupBox, QProgressBar, QStatusBar, QToolBar,
    QSpacerItem, QMessageBox
)
from PyQt6.QtCore import Qt, QTimer, QSize, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QPalette, QIcon, QPixmap, QPainter

from sync_engine import SyncWorker, SyncResult
from sync_utils.audio_analysis import compute_delays, find_all_durations
from sync_utils.video_sync import generate_single_preview, get_first_frame_pts, run_ffmpeg_subprocess
from sync_utils.eeg_video_sync import compare_video_eeg, cut_video_from_start_end
from eeg_module import EEGLiveWidget, EEGReviewWidget
from live_session_tab import LiveSessionTab
from vlc_module import VLCVideoSlot, SyncPlaybackController
from export_module import FullSessionExportWorker, LabelsExporter, ExportProgressDialog
from labels_config import LABELS as PREDEFINED_LABELS, next_colour, save as save_labels

_INT32_MAX = 2_147_483_647

def _clamp_ms(ms) -> int:
    return int(max(0, min(int(ms), _INT32_MAX)))


from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput
from PyQt6.QtGui import QImage


class VideoSurface(QWidget):
    """QPainter-based video surface — no native NSView created."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("background-color: #050506;")
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self._st     = None
        self._bufs   = None
        self._vw     = 1
        self._vh     = 1
        self._vpitch = 4
        self._timer  = QTimer(self)
        self._timer.setInterval(33)  # ~30 fps during playback
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def attach_vmem(self, bufs, st, w, h, pitch, real_w=None):
        self._bufs   = bufs; self._st = st
        self._vw     = w        # buffer width (aligned, used as QImage bytesPerLine / 4)
        self._vh     = h
        self._vpitch = pitch
        self._real_w = real_w if real_w is not None else w  # actual video pixel width

    def _tick(self):
        st = self._st
        if st is None or not st['fresh']:
            return
        st['fresh'] = False
        st['r'], st['d'] = st['d'], st['r']
        self.update()

    def paintEvent(self, event):
        from PyQt6.QtCore import QRectF
        painter = QPainter(self)
        st, bufs = self._st, self._bufs
        if st is not None and bufs is not None:
            # Build QImage using the aligned pitch as bytesPerLine.
            # Crop display to the real video width so the padding columns
            # (which may contain garbage) are never drawn — AND crop the
            # bottom 1 row because VLC's vmem unlock callback can race the
            # last-row write, producing a single-line green/garbled artefact
            # on the bottom edge of the first frame after seeks.
            img = QImage(bufs[st['d']], self._vw, self._vh,
                         self._vpitch, QImage.Format.Format_ARGB32)
            # Crop right padding and bottom row.
            crop_w = min(self._real_w, self._vw)
            crop_h = max(1, self._vh - 1)
            if crop_w < self._vw or crop_h < self._vh:
                img = img.copy(0, 0, crop_w, crop_h)
            sw, sh = self.width(), self.height()
            iw, ih = img.width(), img.height()
            scale  = min(sw / iw, sh / ih)
            dw, dh = iw * scale, ih * scale
            painter.drawImage(QRectF((sw - dw) / 2, (sh - dh) / 2, dw, dh), img)
        else:
            painter.fillRect(self.rect(), Qt.GlobalColor.black)
        painter.end()



def _supplementary_qss():
    """Theme-aware QSS supplementing dt.qss_app() — covers widgets that
    aren't specifically styled by the main stylesheet factories (sliders,
    list widgets, progress bars, combo boxes, group boxes, etc.)."""
    import design_tokens as dt
    return f"""
        QFrame#panel {{ background-color: {dt.card_bg()}; border: 1px solid {dt.border()}; border-radius: {dt.RADIUS_MD}px; }}
        QFrame#video_slot {{ background-color: {dt.canvas_bg()}; border: 1px solid {dt.border()}; border-radius: {dt.RADIUS_MD}px; }}
        QFrame#video_slot:hover {{ border-color: {dt.border_strong()}; }}
        QLabel#panel_title {{ color: {dt.accent()}; font-size: 10px; letter-spacing: 1.8px; font-family: {dt.FONT_UI}; font-weight: 700; padding: 0px; }}
        QLabel#timecode {{ color: {dt.accent()}; font-size: 13px; font-family: {dt.FONT_MONO}; letter-spacing: 0.8px; }}
        QSlider::groove:horizontal {{ height: 3px; background: {dt.border_strong()}; border-radius: 1px; }}
        QSlider::sub-page:horizontal {{ background: {dt.accent()}; height: 3px; border-radius: 1px; }}
        QSlider::handle:horizontal {{ background: {dt.accent()}; width: 12px; height: 12px; margin: -5px 0; border-radius: 6px; }}
        QListWidget {{ background-color: {dt.card_bg()}; border: 1px solid {dt.border()}; border-radius: {dt.RADIUS_MD}px; color: {dt.text_primary()}; font-family: {dt.FONT_UI}; font-size: 12px; outline: none; padding: 4px; }}
        QListWidget::item {{ padding: 8px 12px; border-radius: {dt.RADIUS_SM}px; }}
        QListWidget::item:selected {{ background-color: {dt.accent_ghost()}; color: {dt.accent()}; }}
        QProgressBar {{ background-color: {dt.card_bg()}; border: 1px solid {dt.border()}; height: 4px; text-align: center; color: transparent; border-radius: 2px; }}
        QProgressBar::chunk {{ background-color: {dt.accent()}; border-radius: 2px; }}
        QStatusBar {{ background-color: {dt.canvas_bg()}; border-top: 1px solid {dt.border()}; color: {dt.text_tertiary()}; font-family: {dt.FONT_UI}; font-size: 10px; }}
        QGroupBox {{ border: 1px solid {dt.border()}; border-radius: {dt.RADIUS_MD}px; margin-top: 18px; padding: 12px; font-family: {dt.FONT_UI}; font-size: 10px; letter-spacing: 1.4px; font-weight: 700; color: {dt.text_tertiary()}; }}
        QGroupBox::title {{ subcontrol-origin: margin; left: 14px; padding: 0 6px; color: {dt.text_tertiary()}; letter-spacing: 1.4px; }}
        QComboBox {{ background-color: {dt.card_bg()}; border: 1px solid {dt.border_strong()}; border-radius: {dt.RADIUS_MD}px; color: {dt.text_primary()}; padding: 8px 12px; font-family: {dt.FONT_UI}; font-size: 12px; }}
        QComboBox:hover {{ border-color: {dt.accent()}; }}
    """

APP_STYLE = ""  # Legacy placeholder — kept for compatibility with tests

def make_divider():
    line = QFrame()
    line.setFrameShape(QFrame.Shape.HLine)
    line.setStyleSheet("background-color: #2A2A30; max-height: 1px; border: none;")
    return line

def make_panel_title(text):
    lbl = QLabel(text); lbl.setObjectName("panel_title"); return lbl

def make_source_label(text):
    lbl = QLabel(text)
    lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-family: 'Inter'; letter-spacing: 2px; padding-left: 12px;")
    return lbl


class VideoSlot(QFrame):
    upload_requested = pyqtSignal(int)
    def __init__(self, slot_index, label="CAM", parent=None):
        super().__init__(parent)
        self.slot_index = slot_index; self.label = label
        self.setObjectName("video_slot")
        self.setMinimumSize(200, 140)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._build()
    def _build(self):
        layout = QVBoxLayout(self); layout.setContentsMargins(0,0,0,0); layout.setSpacing(0)
        top_bar = QWidget(); top_bar.setFixedHeight(26)
        top_bar.setStyleSheet("background-color: #0E0E12; border-bottom: 1px solid #2A2A30;")
        tl = QHBoxLayout(top_bar); tl.setContentsMargins(10,0,10,0)
        self.status_dot = QLabel("●"); self.status_dot.setObjectName("status_dot_idle")
        self.slot_label = QLabel(f"{self.label} {self.slot_index:02d}")
        self.slot_label.setStyleSheet("color: #71717A; font-size: 10px; font-family: 'Inter'; letter-spacing: 2px;")
        self.filename_label = QLabel("NO SOURCE")
        self.filename_label.setStyleSheet("color: #2A2A30; font-size: 9px; font-family: 'Inter'; letter-spacing: 1px;")
        tl.addWidget(self.status_dot); tl.addSpacing(6); tl.addWidget(self.slot_label)
        tl.addSpacing(12); tl.addWidget(self.filename_label); tl.addStretch()
        layout.addWidget(top_bar)
        self.main_area = QWidget()
        self.main_area.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.main_area.setStyleSheet("background-color: #0E0E12;")
        ml = QVBoxLayout(self.main_area); ml.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.placeholder = QLabel(f"[ {self.label} {self.slot_index:02d} ]")
        self.placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.placeholder.setStyleSheet("color: #2A2A30; font-size: 16px; font-family: 'Inter'; letter-spacing: 4px;")
        ml.addWidget(self.placeholder); layout.addWidget(self.main_area)
    def set_active(self, filename=""):
        self.status_dot.setStyleSheet("color: #22c55e; font-size: 10px;")
        if filename:
            self.filename_label.setText(filename.split("/")[-1][:28])
            self.filename_label.setStyleSheet("color: #A1A1AA; font-size: 9px; font-family: 'Inter'; letter-spacing: 1px;")
        self.placeholder.setText("")
    def set_idle(self):
        self.status_dot.setStyleSheet("color: #2A2A30; font-size: 10px;")
        self.filename_label.setText("NO SOURCE"); self.placeholder.setText(f"[ {self.label} {self.slot_index:02d} ]")


class EEGPanel(QFrame):
    def __init__(self, channel_id=1, parent=None):
        super().__init__(parent); self.channel_id = channel_id
        self.setObjectName("panel"); self.setMinimumHeight(120)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred); self._build()
    def _build(self):
        layout = QVBoxLayout(self); layout.setContentsMargins(0,0,0,0); layout.setSpacing(0)
        top_bar = QWidget(); top_bar.setFixedHeight(26)
        top_bar.setStyleSheet("background-color: #0E0E12; border-bottom: 1px solid #2A2A30;")
        tb = QHBoxLayout(top_bar); tb.setContentsMargins(10,0,10,0)
        dot = QLabel("●"); dot.setStyleSheet("color: #2A2A30; font-size: 10px;")
        lbl = QLabel(f"EEG CHANNEL {self.channel_id}  —  MUSE-S")
        lbl.setStyleSheet("color: #71717A; font-size: 10px; font-family: 'Inter'; letter-spacing: 2px;")
        self.hz_label = QLabel("256 HZ")
        self.hz_label.setStyleSheet("color: #2A2A30; font-size: 9px; font-family: 'Inter'; letter-spacing: 1px;")
        tb.addWidget(dot); tb.addSpacing(6); tb.addWidget(lbl); tb.addStretch(); tb.addWidget(self.hz_label)
        layout.addWidget(top_bar)
        ph = QLabel(f"EEG plot will render here — channel {self.channel_id}")
        ph.setAlignment(Qt.AlignmentFlag.AlignCenter)
        ph.setStyleSheet("color: #2A2A30; font-size: 11px; font-family: 'Inter'; letter-spacing: 2px; padding: 20px;")
        layout.addWidget(ph)


class SourceRow(QWidget):
    file_loaded = pyqtSignal(int, str)
    def __init__(self, source_id, label, accept_filter, parent=None):
        super().__init__(parent); self.source_id = source_id; self.file_path = None
        self.accept_filter = accept_filter; self._build(label)
    def _build(self, label):
        layout = QHBoxLayout(self); layout.setContentsMargins(0,3,0,3); layout.setSpacing(6)
        self.status = QLabel("○"); self.status.setFixedWidth(14)
        self.status.setStyleSheet("color: #A1A1AA; font-size: 12px; font-family: 'Inter';")
        self.type_lbl = QLabel(label); self.type_lbl.setFixedWidth(100)
        self.type_lbl.setStyleSheet("color: #A1A1AA; font-size: 10px; font-family: 'Inter'; letter-spacing: 1px;")
        self.file_lbl = QLabel("—")
        self.file_lbl.setStyleSheet("color: #A1A1AA; font-size: 10px; font-family: 'Inter';")
        self.file_lbl.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        self.file_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.NoTextInteraction)
        self.offset_lbl = QLabel(""); self.offset_lbl.setVisible(False)
        btn = QPushButton("UPLOAD"); btn.setFixedWidth(72); btn.setFixedHeight(26)
        btn.setStyleSheet("background-color: #1C1C21; border: 1px solid #71717A; color: #A1A1AA; font-family: 'Inter'; font-size: 10px; padding: 0 6px;")
        btn.clicked.connect(self._pick_file)
        layout.addWidget(self.status); layout.addWidget(self.type_lbl); layout.addWidget(self.file_lbl); layout.addWidget(btn)
    def _pick_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select file", "", self.accept_filter)
        if path:
            self.set_path(path)
    def set_path(self, path: str):
        """Programmatic equivalent of picking a file via the UPLOAD button.
        Used by LiveSessionTab → SyncReviewTab auto-population after a capture
        session finishes."""
        if not path:
            return
        self.file_path = path
        name = path.split("/")[-1]; short = name[:12] + "…" if len(name) > 12 else name
        self.file_lbl.setText(short); self.file_lbl.setStyleSheet("color: #ECEDEE; font-size: 10px; font-family: 'Inter';")
        self.status.setText("●"); self.status.setStyleSheet("color: #22c55e; font-size: 12px; font-family: 'Inter';")
        self.file_loaded.emit(self.source_id, path)
    def set_offset(self, seconds):
        if seconds == 0.0:
            self.offset_lbl.setText("BASE"); self.offset_lbl.setStyleSheet("color: #637DFF; font-size: 10px; font-family: 'Inter'; text-align: right;")
        else:
            sign = "+" if seconds > 0 else ""
            self.offset_lbl.setText(f"{sign}{seconds:.3f}s"); self.offset_lbl.setStyleSheet("color: #4a9eff; font-size: 10px; font-family: 'Inter'; text-align: right;")
    def set_confidence(self, confidence, method):
        if method != "xcorr": return
        if confidence >= 0.6: badge, color = "✓", "#22c55e"
        elif confidence >= 0.3: badge, color = "~", "#f59e0b"
        else: badge, color = "?", "#ef4444"
        current = self.type_lbl.text().rstrip(" ✓~?")
        self.type_lbl.setText(f"{current} {badge}")
        self.type_lbl.setStyleSheet(f"color: {color}; font-size: 10px; font-family: 'Inter'; letter-spacing: 1px;")


import pandas as pd


class MainEditorSyncWorker(QThread):
    progress = pyqtSignal(int, str)
    finished = pyqtSignal(list, list)
    error    = pyqtSignal(str)

    def __init__(self, video_paths, eeg_paths=None, pivot_index=None, parent=None):
        super().__init__(parent)
        self.video_paths = video_paths; self.eeg_paths = eeg_paths or []
        self.pivot_index = pivot_index; self._temp_dir = tempfile.TemporaryDirectory()

    def run(self):
        try:
            original_video_paths = list(self.video_paths)
            self.progress.emit(5, "Analyzing durations...")
            durations = find_all_durations(original_video_paths)

            if self.eeg_paths:
                self.progress.emit(10, "EEG data detected — computing EEG window offset...")
                try:
                    pivot = int(_np.argmax(durations))
                    eeg_start, eeg_end = compare_video_eeg(original_video_paths[pivot], self.eeg_paths[0], durations[pivot])
                    self.progress.emit(15, f"EEG window: {eeg_start:.1f}s → {eeg_end:.1f}s in pivot video")
                    print(f"[EEG sync] pivot video EEG window: {eeg_start:.3f}s → {eeg_end:.3f}s")
                except Exception as e:
                    self.progress.emit(15, f"EEG offset skipped: {e}"); print(f"[EEG sync warning] {e}")

            self.progress.emit(20, "Computing inter-camera delays via audio xcorr...")
            raw_delays = compute_delays(original_video_paths)
            min_delay = min(raw_delays)
            norm_delays = [d - min_delay for d in raw_delays]
            max_norm_delay = max(norm_delays)
            print(f"Normalised delays: {[round(d,3) for d in norm_delays]}  (max={max_norm_delay:.3f}s)")

            self.progress.emit(90, "Computing VLC seek offsets...")
            # Each clip seeks forward by its own normalised delay so all clips
            # reach the same real-world moment at playhead t=0.
            # The reference clip (delay=0) seeks to 0 ms — it is already at the
            # right start point.  Every other clip skips its "early" head footage.
            # (Previous formula was max_norm_delay - d, which was inverted:
            #  the reference got the largest seek and early clips got 0.)
            seek_ms = [_clamp_ms(d * 1000) for d in norm_delays]
            for i, (path, s) in enumerate(zip(original_video_paths, seek_ms)):
                print(f"  clip {i} ({os.path.basename(path)}): delay={norm_delays[i]:.3f}s  seek={s}ms")

            self.progress.emit(100, "Sync complete.")
            self.finished.emit(original_video_paths, norm_delays + [max_norm_delay] + [float(s) for s in seek_ms])
        except Exception as e:
            self.error.emit(str(e))


class SyncReviewTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.media_players      = [None, None, None, None]
        self._video_widgets_qt  = [None, None, None, None]
        self._vmem_states       = [None, None, None, None]
        self.video_paths        = [None, None, None, None]
        self.video_widgets      = []
        self.eeg_file_name_1 = None; self.eeg_file_name_2 = None
        self.sync_result = None; self._worker = None
        self._temp_paths = []; self._delays = []; self._residuals_ms = []
        self._post_sync_offsets_ms = [0, 0, 0, 0]
        self._pos_timer = QTimer(self); self._pos_timer.setInterval(100)
        self._pos_timer.timeout.connect(self._poll_position)
        self._app_ref = None
        self._build()
        self._apply_theme()
        import design_tokens as _dt
        _dt.on_theme_change(self._apply_theme)

    def _apply_theme(self):
        """Re-apply theme-reactive styles to the tab's visible surfaces.
        Covers toolbar, upload panel, sources, preview background."""
        import design_tokens as _dt
        self.setStyleSheet(f"SyncReviewTab {{ background: {_dt.canvas_bg()}; }}")
        for w in self.findChildren(QWidget):
            ss = w.styleSheet()
            if not ss: continue
            new_ss = (ss
                .replace("background-color: #0E0E12", f"background-color: {_dt.canvas_bg()}")
                .replace("background-color: #000", f"background-color: {_dt.canvas_bg()}")
                .replace("background: #000", f"background: {_dt.canvas_bg()}")
                .replace("background-color: #050506", f"background-color: {_dt.canvas_bg()}")
                .replace("background-color: #1C1C21", f"background-color: {_dt.card_bg()}")
                .replace("background-color: #1F2538", f"background-color: {_dt.accent_ghost()}")
                .replace("border: 1px solid #2A2A30", f"border: 1px solid {_dt.border_strong()}")
                .replace("border-bottom: 1px solid #2A2A30", f"border-bottom: 1px solid {_dt.border_strong()}")
                .replace("border: 1px solid #637DFF", f"border: 1px solid {_dt.accent()}")
                .replace("border: 1px solid #4a9eff", f"border: 1px solid {_dt.accent()}")
                .replace("border: 1px solid #71717A", f"border: 1px solid {_dt.border_strong()}")
                .replace("color: #2A2A30", f"color: {_dt.text_tertiary()}")
                .replace("color: #71717A", f"color: {_dt.text_tertiary()}")
                .replace("color: #A1A1AA", f"color: {_dt.text_secondary()}")
                .replace("color: #ECEDEE", f"color: {_dt.text_primary()}")
                .replace("color: #637DFF", f"color: {_dt.accent()}")
                .replace("color: #4a9eff", f"color: {_dt.accent()}")
            )
            if new_ss != ss:
                w.setStyleSheet(new_ss)
        for w in self.findChildren(QWidget):
            try:
                s = w.style(); s.unpolish(w); s.polish(w); w.update()
            except Exception: pass

    def _build(self):
        root = QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        toolbar = QWidget(); toolbar.setFixedHeight(44)
        toolbar.setStyleSheet("background-color: #0E0E12; border-bottom: 1px solid #2A2A30;")
        tb = QHBoxLayout(toolbar); tb.setContentsMargins(16,0,16,0); tb.setSpacing(8)
        tb.addWidget(make_panel_title("SYNC + REVIEW")); tb.addStretch()
        self.sync_btn = QPushButton("AUTO-SYNC"); self.sync_btn.setFixedHeight(28)
        self.sync_btn.setStyleSheet("background-color: #1F2538; border: 1px solid #637DFF; color: #637DFF; font-family: 'Inter'; font-size: 10px; letter-spacing: 2px; padding: 0 16px;")
        self.export_btn = QPushButton("EXPORT SYNCED DATA"); self.export_btn.setFixedHeight(28)
        self.export_btn.setStyleSheet("background-color: transparent; border: 1px solid #4a9eff; color: #4a9eff; font-family: 'Inter'; font-size: 10px; letter-spacing: 1px; padding: 0 14px;")
        self.export_btn.clicked.connect(self._export_synced_data)
        tb.addWidget(self.sync_btn); tb.addWidget(self.export_btn); root.addWidget(toolbar)

        splitter = QSplitter(Qt.Orientation.Horizontal); splitter.setHandleWidth(1)
        upload_widget = QWidget(); upload_widget.setFixedWidth(400)
        upload_widget.setStyleSheet("background-color: #0E0E12;")
        upload_layout = QVBoxLayout(upload_widget); upload_layout.setContentsMargins(10,16,10,16); upload_layout.setSpacing(6)
        upload_layout.addWidget(make_source_label("DATA SOURCES")); upload_layout.addSpacing(6)
        header = QHBoxLayout(); header.setSpacing(6)
        for txt, w in [("", 14), ("TYPE", 100), ("FILE", 0), ("", 80)]:
            h = QLabel(txt); h.setStyleSheet("color: #2A2A30; font-size: 9px; font-family: 'Inter'; letter-spacing: 2px;")
            if w: h.setFixedWidth(w)
            else: h.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            header.addWidget(h)
        upload_layout.addLayout(header); upload_layout.addWidget(make_divider())
        self.sources = []
        source_defs = [
            ("DSLR  01","Video Files (*.mp4 *.mov *.avi *.MP4 *.MOV)"),("DSLR  02","Video Files (*.mp4 *.mov *.avi *.MP4 *.MOV)"),
            ("POV     01","Video Files (*.mp4 *.mov *.avi *.MP4 *.MOV)"),("POV     02","Video Files (*.mp4 *.mov *.avi *.MP4 *.MOV)"),
            ("MUSE-S  01","CSV Files (*.csv)"),("MUSE-S  02","CSV Files (*.csv)"),
        ]
        for i, (lbl, filt) in enumerate(source_defs):
            row = SourceRow(i, lbl, filt); upload_layout.addWidget(row)
            if i == 3: upload_layout.addWidget(make_divider())
            self.sources.append(row); row.file_loaded.connect(self._on_file_loaded)
        upload_layout.addWidget(make_divider())
        self.sync_status = QLabel("AWAITING SOURCES")
        self.sync_status.setStyleSheet("color: #2A2A30; font-size: 10px; font-family: 'Inter'; letter-spacing: 2px; padding: 8px 0;")
        upload_layout.addWidget(self.sync_status)
        self.sync_progress = QProgressBar(); self.sync_progress.setValue(0)
        self.sync_progress.setFixedHeight(3); self.sync_progress.setVisible(False)
        upload_layout.addWidget(self.sync_progress); upload_layout.addStretch()
        self.goto_label_btn = QPushButton("PROCEED TO LABELLING  →"); self.goto_label_btn.setEnabled(False)
        self.goto_label_btn.setStyleSheet("background-color: #1F2538; border: 1px solid #637DFF; color: #637DFF; font-family: 'Inter'; font-size: 10px; letter-spacing: 2px; padding: 10px;")
        upload_layout.addWidget(self.goto_label_btn); splitter.addWidget(upload_widget)

        preview_widget = QWidget(); preview_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        preview_layout = QVBoxLayout(preview_widget); preview_layout.setContentsMargins(0,0,0,0); preview_layout.setSpacing(0)
        right_scroll = QScrollArea(); right_scroll.setWidgetResizable(True)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        right_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        right_scroll.setStyleSheet("QScrollArea { background: #000; border: none; } QScrollBar:vertical { background: #0E0E12; width: 8px; border: none; } QScrollBar::handle:vertical { background: #2A2A30; border-radius: 4px; min-height: 24px; } QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; border: none; }")
        right_content = QWidget(); right_content.setStyleSheet("background-color: #000;")
        right_vbox = QVBoxLayout(right_content); right_vbox.setContentsMargins(0,0,0,0); right_vbox.setSpacing(0)

        class _AspectVideoArea(QWidget):
            HEADER_H = 26; SPACING = 2
            def resizeEvent(self, event):
                super().resizeEvent(event)
                cell_w = max(100, (self.width() - self.SPACING) // 2); cell_h = int(cell_w * 9 / 16)
                self.setFixedHeight((cell_h + self.HEADER_H) * 2 + self.SPACING)

        video_area = _AspectVideoArea(); video_area.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        video_area.setStyleSheet("background-color: #000;")
        va_layout = QVBoxLayout(video_area); va_layout.setContentsMargins(0,0,0,0); va_layout.setSpacing(0)
        vgrid = QGridLayout(); vgrid.setSpacing(2); vgrid.setContentsMargins(0,0,0,0)
        vgrid.setRowStretch(0,1); vgrid.setRowStretch(1,1); vgrid.setColumnStretch(0,1); vgrid.setColumnStretch(1,1)

        def _make_video_slot(cam_label, placeholder_text):
            slot = QWidget(); slot.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            slot_layout = QVBoxLayout(slot); slot_layout.setContentsMargins(0,0,0,0); slot_layout.setSpacing(0)
            hdr = QWidget(); hdr.setFixedHeight(26)
            hdr.setStyleSheet("background-color: #0E0E12; border-bottom: 1px solid #2A2A30;")
            hdr_layout = QHBoxLayout(hdr); hdr_layout.setContentsMargins(8,0,8,0); hdr_layout.setSpacing(6)
            dot = QLabel("●"); dot.setStyleSheet("color: #2A2A30; font-size: 10px;"); dot.setFixedWidth(12)
            name_lbl = QLabel(cam_label); name_lbl.setStyleSheet("color: #A1A1AA; font-size: 9px; font-family: 'Inter'; letter-spacing: 2px;")
            status_lbl = QLabel("— NO FILE"); status_lbl.setStyleSheet("color: #2A2A30; font-size: 9px; font-family: 'Inter';")
            hdr_layout.addWidget(dot); hdr_layout.addWidget(name_lbl); hdr_layout.addWidget(status_lbl); hdr_layout.addStretch()
            slot_layout.addWidget(hdr)
            vlc_container = QWidget(); vlc_container.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
            vlc_container.setStyleSheet("background-color: #0E0E12;")
            slot_layout.addWidget(vlc_container, 1)
            ph = QLabel(placeholder_text, vlc_container); ph.setAlignment(Qt.AlignmentFlag.AlignCenter)
            ph.setStyleSheet("color: #2A2A30; font-size: 10px; font-family: 'Inter'; letter-spacing: 1px; background-color: transparent;")
            ph.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True); ph.show()
            def _resize_container(event, _ph=ph, _c=vlc_container): _ph.setGeometry(0, 0, _c.width(), _c.height())
            vlc_container.resizeEvent = _resize_container
            def _resize_slot(event, _hdr=hdr): _hdr.raise_()
            slot.resizeEvent = _resize_slot
            slot._dot = dot; slot._status = status_lbl; slot._ph = ph; slot._vlc_container = vlc_container
            return slot, vlc_container

        slot1, self.video_display_1 = _make_video_slot("DSLR  01", "[ DSLR 01  —  UPLOAD VIDEO TO VIEW ]")
        slot2, self.video_display_2 = _make_video_slot("DSLR  02", "[ DSLR 02  —  UPLOAD VIDEO TO VIEW ]")
        slot3, self.video_display_3 = _make_video_slot("POV     01", "[ POV 01  —  UPLOAD VIDEO TO VIEW ]")
        slot4, self.video_display_4 = _make_video_slot("POV     02", "[ POV 02  —  UPLOAD VIDEO TO VIEW ]")
        self._video_slots = [slot1, slot2, slot3, slot4]
        self.video_widgets = [self.video_display_1, self.video_display_2, self.video_display_3, self.video_display_4]
        vgrid.addWidget(slot1,0,0); vgrid.addWidget(slot2,0,1); vgrid.addWidget(slot3,1,0); vgrid.addWidget(slot4,1,1)
        va_layout.addLayout(vgrid); right_vbox.addWidget(video_area)

        eeg_row_widget = QWidget(); eeg_row_widget.setFixedHeight(320)
        eeg_row_widget.setStyleSheet("background-color: #0E0E12;")
        eeg_row_layout = QVBoxLayout(eeg_row_widget); eeg_row_layout.setContentsMargins(0,0,0,0); eeg_row_layout.setSpacing(0)
        eeg_row_layout.addWidget(make_source_label("EEG OVERLAY"))
        eeg_cols_widget = QWidget(); eeg_cols_widget.setStyleSheet("background-color: #0E0E12;")
        eeg_cols = QHBoxLayout(eeg_cols_widget); eeg_cols.setContentsMargins(12,4,12,8); eeg_cols.setSpacing(6)
        self.eeg_review_1 = EEGReviewWidget(channel_id=1); self.eeg_review_2 = EEGReviewWidget(channel_id=2)
        eeg_cols.addWidget(self.eeg_review_1); eeg_cols.addWidget(self.eeg_review_2)
        eeg_row_layout.addWidget(eeg_cols_widget, 1); right_vbox.addWidget(eeg_row_widget)
        right_scroll.setWidget(right_content); preview_layout.addWidget(right_scroll, stretch=1)

        controls = QWidget(); controls.setFixedHeight(52)
        controls.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        controls.setStyleSheet("background-color: #0E0E12; border-top: 2px solid #2A2A30;")
        ctrl_layout = QHBoxLayout(controls); ctrl_layout.setContentsMargins(16,0,16,0); ctrl_layout.setSpacing(10)
        self.play_btn = QPushButton("▶  PLAY"); self.play_btn.setFixedWidth(110); self.play_btn.setFixedHeight(34)
        self.play_btn.setEnabled(False)
        self.play_btn.setStyleSheet("background-color: #1C1C21; border: 1px solid #71717A; color: #ECEDEE; font-family: 'Inter'; font-size: 11px; letter-spacing: 1px; padding: 6px;")
        self.play_btn.clicked.connect(self._toggle_play)
        self.tc_label = QLabel("00:00:00.000"); self.tc_label.setObjectName("timecode"); self.tc_label.setFixedWidth(110)
        self.time_slider = QSlider(Qt.Orientation.Horizontal); self.time_slider.setRange(0,0); self.time_slider.setValue(0)
        self.time_slider.sliderMoved.connect(self._set_position)
        self.duration_label = QLabel("--:--:--.---")
        self.duration_label.setStyleSheet("color: #A1A1AA; font-size: 11px; font-family: 'Inter'; letter-spacing: 1px;")
        self.duration_label.setFixedWidth(90)
        ctrl_layout.addWidget(self.play_btn); ctrl_layout.addWidget(self.tc_label)
        ctrl_layout.addWidget(self.time_slider); ctrl_layout.addWidget(self.duration_label)
        splitter.addWidget(preview_widget); splitter.setSizes([400, 1200])
        splitter.setStretchFactor(0,0); splitter.setStretchFactor(1,1)
        root.addWidget(splitter, stretch=1); root.addWidget(controls)
        self.sync_btn.clicked.connect(self._run_sync); self.goto_label_btn.clicked.connect(self._request_label_tab)

    # ── Video loading — VLC vmem → QPainter (no native NSView / Metal) ──────────
    #
    # VLC decodes the video and writes BGRA pixels into a ctypes buffer.
    # A display callback fires for each frame, wraps the buffer in a QImage,
    # and schedules an update() on the VideoSurface widget.  VideoSurface draws
    # with QPainter inside paintEvent — it is a plain QWidget with no native
    # NSView, so it is fully clipped by its parent and can never overflow the
    # header or tab bar regardless of macOS compositor behaviour.

    def _load_video_vmem(self, video_num, path):
        import ctypes
        i = video_num - 1; self.video_paths[i] = path
        container = self.video_widgets[i]

        old = self.media_players[i]
        if old is not None: old.stop()
        old_vw = self._video_widgets_qt[i]
        if old_vw is not None:
            if container.layout(): container.layout().removeWidget(old_vw)
            old_vw.setParent(None); old_vw.deleteLater()
            self._video_widgets_qt[i] = None

        surface = VideoSurface(container)
        if container.layout() is None:
            from PyQt6.QtWidgets import QVBoxLayout as _VBL
            _lay = _VBL(container); _lay.setContentsMargins(0,0,0,0); _lay.setSpacing(0)
        container.layout().addWidget(surface); surface.show()
        self._video_widgets_qt[i] = surface

        src_w, src_h = 1920, 1080
        try:
            import ffmpeg as _ff
            probe = _ff.probe(path)
            vs = next((s for s in probe["streams"] if s["codec_type"] == "video"), None)
            if vs: src_w = int(vs.get("width", 1920)); src_h = int(vs.get("height", 1080))
        except Exception: pass
        width = src_w // 2; height = src_h // 2
        # Align pitch to a 32-byte boundary.
        # VLC's swscaler pads rows internally to 16 bytes; QImage expects the
        # same pitch we tell VLC.  A mismatch on the last scanline causes the
        # green artefact seen on the bottom-right camera.
        raw_pitch = width * 4
        pitch = (raw_pitch + 31) & ~31   # round up to next multiple of 32
        # Re-derive the buffer width from the aligned pitch so QImage rows match
        buf_width = pitch // 4           # pixels per row as seen by QImage

        bufs = [(ctypes.c_uint8 * (pitch * height))() for _ in range(3)]
        # Initialise every byte so that if VLC's lock callback fires before
        # the first full frame lands, the stale buffer shows opaque black
        # rather than whatever colour the uninitialised bytes happen to
        # decode to. In BGRA, zeroed memory is transparent black; random
        # memory often reads as green (G byte dominates). We initialise to
        # opaque black — zero BGR + alpha 0xFF.
        #
        # The bottom-line green artefact seen on the bottom-left camera slot
        # comes from the same mechanism: VLC's last-row write sometimes races
        # the lock callback, so the bottom scanline is read while partially
        # uninitialised. Zeroing the buffer up-front eliminates the artefact
        # everywhere.
        import struct
        _black_px = struct.pack("BBBB", 0x00, 0x00, 0x00, 0xFF)  # BGRA opaque black
        _row = _black_px * buf_width
        for b in bufs:
            ctypes.memmove(b, _row * height, pitch * height)
        st   = {'w': 0, 'r': 1, 'd': 2, 'fresh': False}
        # Pass buf_width (aligned) so QImage reads the correct row stride,
        # and real_w (actual pixels) so paintEvent crops the padding columns.
        surface.attach_vmem(bufs, st, buf_width, height, pitch, real_w=width)

        @vlc.CallbackDecorators.VideoLockCb
        def _lock(opaque, planes):
            planes[0] = ctypes.cast(bufs[st['w']], ctypes.c_void_p); return None

        @vlc.CallbackDecorators.VideoUnlockCb
        def _unlock(opaque, picture, planes):
            st['w'], st['r'] = st['r'], st['w']; st['fresh'] = True

        @vlc.CallbackDecorators.VideoDisplayCb
        def _display(opaque, picture): pass

        _inst = vlc.Instance()
        player = _inst.media_player_new()
        player._vlc_instance_ref = _inst
        player.video_set_callbacks(_lock, _unlock, _display, None)
        # Tell VLC: decode to `width` pixels per row, but write rows with
        # the aligned `pitch` bytes — this matches what the buffer was allocated for.
        player.video_set_format("BGRA", width, height, pitch)
        media = _inst.media_new(Path(path).as_uri()); player.set_media(media)
        player._vmem_refs = (_lock, _unlock, _display, bufs, st)
        self.media_players[i] = player

        em = player.event_manager()
        em.event_attach(vlc.EventType.MediaPlayerTimeChanged,   lambda e, _i=i: self._vlc_time_changed(_i, e))
        em.event_attach(vlc.EventType.MediaPlayerLengthChanged, lambda e, _i=i: self._vlc_length_changed(_i, e))

        def _prewarm(_p=player):
            _p.play()
            def _pause_when_ready(_count=[0], _pp=_p):
                if _pp.get_state() == vlc.State.Playing:
                    _pp.pause(); _pp.set_time(0)
                elif _count[0] < 100:
                    _count[0] += 1; QTimer.singleShot(100, _pause_when_ready)
            QTimer.singleShot(100, _pause_when_ready)
        QTimer.singleShot(200, _prewarm)

    # ── Platform dispatch — Windows uses HWND, macOS uses vmem ──────────────

    def _load_video(self, video_num: int, path: str):
        """
        Platform-aware video loader.
        Windows: give VLC the HWND directly for GPU-accelerated rendering.
        macOS/Linux: use vmem triple-buffer to avoid NSView compositor issues.
        """
        import sys as _sys
        if _sys.platform == "win32":
            self._load_video_hwnd(video_num, path)
        else:
            self._load_video_vmem(video_num, path)

    def _load_video_hwnd(self, video_num: int, path: str):
        """
        Windows renderer — give VLC the native HWND for hardware-accelerated
        compositing. No ctypes buffer copies, no QPainter blits.
        """
        i = video_num - 1
        self.video_paths[i] = path
        container = self.video_widgets[i]

        old = self.media_players[i]
        if old is not None:
            old.stop()
        old_vw = self._video_widgets_qt[i]
        if old_vw is not None:
            if container.layout():
                container.layout().removeWidget(old_vw)
            old_vw.setParent(None)
            old_vw.deleteLater()
            self._video_widgets_qt[i] = None

        from PyQt6.QtWidgets import QVBoxLayout as _VBL
        win_widget = QWidget(container)
        win_widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        win_widget.setStyleSheet("background-color: #050506;")
        if container.layout() is None:
            _lay = _VBL(container)
            _lay.setContentsMargins(0, 0, 0, 0)
        container.layout().addWidget(win_widget)
        win_widget.show()
        self._video_widgets_qt[i] = win_widget

        _inst = vlc.Instance()
        player = _inst.media_player_new()
        player._vlc_instance_ref = _inst

        hwnd = int(win_widget.winId())
        player.set_hwnd(hwnd)

        media = _inst.media_new(Path(path).as_uri())
        player.set_media(media)
        self.media_players[i] = player

        em = player.event_manager()
        em.event_attach(vlc.EventType.MediaPlayerTimeChanged,
                        lambda e, _i=i: self._vlc_time_changed(_i, e))
        em.event_attach(vlc.EventType.MediaPlayerLengthChanged,
                        lambda e, _i=i: self._vlc_length_changed(_i, e))

        def _prewarm(_p=player):
            _p.play()
            def _pause_when_ready(_count=[0], _pp=_p):
                if _pp.get_state() == vlc.State.Playing:
                    _pp.pause(); _pp.set_time(0)
                elif _count[0] < 100:
                    _count[0] += 1; QTimer.singleShot(80, _pause_when_ready)
            QTimer.singleShot(100, _pause_when_ready)
        QTimer.singleShot(200, _prewarm)


    def _raise_ui_above_vlc(self) -> None:
        pass  # vmem uses no native view

    def _vlc_time_changed(self, player_idx, event):
        if self.sync_result is not None: return
        p = self.media_players[player_idx]
        if p:
            ms = p.get_time()
            if ms >= 0: QTimer.singleShot(0, lambda: self._position_changed(ms))

    def _vlc_length_changed(self, player_idx, event):
        p = self.media_players[player_idx]
        if p:
            ms = p.get_length()
            if ms > 0: QTimer.singleShot(0, lambda: self._duration_changed(ms))

    def _on_file_loaded(self, source_id, path):
        if source_id < 4:
            self._load_video(source_id + 1, path); self.play_btn.setEnabled(True)
            slot = self._video_slots[source_id]; slot._ph.hide()
            fname = path.split("/")[-1]; short = fname[:12] + "…" if len(fname) > 12 else fname
            slot._dot.setStyleSheet("color: #22c55e; font-size: 10px;")
            slot._status.setText(f"— {short}"); slot._status.setStyleSheet("color: #ECEDEE; font-size: 9px; font-family: 'Inter';")
        elif source_id == 4:
            self.eeg_file_name_1 = path
            self._load_eeg_async(path, self.eeg_review_1)
        elif source_id == 5:
            self.eeg_file_name_2 = path
            self._load_eeg_async(path, self.eeg_review_2)

    def _load_eeg_async(self, path: str, widget) -> None:
        """Load a Muse CSV via a QThread so delivery back to the main thread is safe."""
        # QTimer.singleShot from a plain daemon thread is not safe on macOS —
        # it silently drops the call. Use a QThread with a signal instead.
        class _EEGLoader(QThread):
            done = pyqtSignal(object)  # emits the DataFrame
            def __init__(self, p, parent=None):
                super().__init__(parent); self._p = p
            def run(self):
                try:
                    df = pd.read_csv(self._p)
                    print(f"[EEG load] columns: {list(df.columns)[:8]}  rows: {len(df)}")
                    col_map = {c.lower(): c for c in df.columns}
                    if 'timestamps' not in df.columns and 'timestamps' in col_map:
                        df = df.rename(columns={col_map['timestamps']: 'timestamps'})
                    self.done.emit(df)
                except Exception as e:
                    print(f"[EEG load error] {e}")

        loader = _EEGLoader(path, parent=self)
        # Keep reference so GC doesn't destroy it before it finishes
        if not hasattr(self, '_eeg_loaders'):
            self._eeg_loaders = []
        self._eeg_loaders.append(loader)

        def _on_done(df, _w=widget, _l=loader):
            try:
                _w.load(df, offset_sec=0.0)
            except Exception as e:
                import traceback; traceback.print_exc()
            finally:
                # Wait for the thread's run() to fully exit before letting
                # Python GC reclaim it — prevents "QThread destroyed while
                # still running" on macOS.
                try: _l.wait(2000)
                except Exception: pass
                if _l in self._eeg_loaders:
                    self._eeg_loaders.remove(_l)

        loader.done.connect(_on_done)
        loader.start()

    def shutdown(self) -> None:
        """Cleanly stop any in-flight loader threads before Qt teardown."""
        for loader in list(getattr(self, '_eeg_loaders', [])):
            try:
                loader.quit()
                loader.wait(2000)
            except Exception:
                pass
        self._eeg_loaders = []
        # Stop the sync analysis worker if it's mid-run
        worker = getattr(self, '_worker', None)
        if worker is not None:
            try:
                worker.quit()
                worker.wait(2000)
            except Exception:
                pass
        # Stop the drift heartbeat timer
        hb = getattr(self, '_drift_hb', None)
        if hb is not None:
            try: hb.stop()
            except Exception: pass

    def _raise_overlays(self): pass

    def _nudge_drift(self):
        """
        Drift-correction heartbeat — runs every 2 s during playback.
        If any player has drifted more than 150 ms from the reference
        player's global time, nudge it back.
        global_t = player_local_time - seek_offset  (reference seek = 0).
        """
        active = [p for p in self.media_players if p and
                  p.get_state() == vlc.State.Playing]
        if len(active) < 2:
            return
        seek_targets = getattr(self, "_residuals_ms", [])
        if not seek_targets:
            return
        # Use the clip with seek=0 (the reference) as the clock source
        ref_idx = next(
            (i for i, s in enumerate(seek_targets) if s == 0),
            next((i for i, p in enumerate(self.media_players) if p and
                  p.get_state() == vlc.State.Playing), 0)
        )
        ref_p = self.media_players[ref_idx]
        if ref_p is None:
            return
        ref_global = ref_p.get_time()   # seek=0 so global_t = local_t
        for i, p in enumerate(self.media_players):
            if p and p.get_state() == vlc.State.Playing and i != ref_idx:
                my_seek = seek_targets[i] if i < len(seek_targets) else 0
                p_global = p.get_time() - my_seek
                if abs(p_global - ref_global) > 150:
                    p.set_time(_clamp_ms(ref_global + my_seek))

    def _toggle_play(self):
        active = [p for p in self.media_players if p]
        any_playing = any(p.get_state() == vlc.State.Playing for p in active)
        if any_playing:
            for p in active: p.pause()
            self.play_btn.setText("▶  PLAY"); self._pos_timer.stop()
            if hasattr(self, '_drift_hb'): self._drift_hb.stop()
        else:
            for p in active: p.play()
            self.play_btn.setText("⏸  PAUSE"); self._pos_timer.start()
            if hasattr(self, '_drift_hb') and getattr(self, 'sync_result', None): self._drift_hb.start()

    def _set_position(self, position_ms):
        # With the corrected sync formula: each clip's local time = global_t + seek_offset.
        # The reference clip (seek=0) plays at exactly global_t.
        seek_targets = getattr(self, "_residuals_ms", [])
        for i, p in enumerate(self.media_players):
            if p:
                my_seek = seek_targets[i] if seek_targets and i < len(seek_targets) else 0
                p.set_time(_clamp_ms(position_ms + my_seek))
        self._update_tc(position_ms)
        self.eeg_review_1.set_playhead(position_ms / 1000.0)
        self.eeg_review_2.set_playhead(position_ms / 1000.0)

    def _position_changed(self, ms):
        if self.sync_result is not None: return
        self.time_slider.blockSignals(True); self.time_slider.setValue(_clamp_ms(ms)); self.time_slider.blockSignals(False)
        self._update_tc(ms)

    def _duration_changed(self, ms):
        if self.sync_result is not None: return
        if ms > 0:
            self.time_slider.setRange(0, _clamp_ms(ms))
            secs = ms / 1000.0; h = int(secs//3600); m = int((secs%3600)//60); s = secs%60
            self.duration_label.setText(f"{h:02d}:{m:02d}:{s:06.3f}")

    def _poll_position(self):
        # Read global_t from the reference player (seek=0 or smallest seek).
        # global_t = player_local_time - seek_offset.
        seek_targets = getattr(self, "_residuals_ms", [])
        for i, p in enumerate(self.media_players):
            if p:
                t = p.get_time()
                my_seek = seek_targets[i] if seek_targets and i < len(seek_targets) else 0
                global_t = _clamp_ms(t - my_seek)
                self.time_slider.blockSignals(True)
                self.time_slider.setValue(global_t)
                self.time_slider.blockSignals(False)
                self._update_tc(global_t)
                self.eeg_review_1.set_playhead(global_t / 1000.0)
                self.eeg_review_2.set_playhead(global_t / 1000.0)
                break

    def _update_tc(self, ms):
        secs = ms / 1000.0; h = int(secs//3600); m = int((secs%3600)//60); s = secs%60
        self.tc_label.setText(f"{h:02d}:{m:02d}:{s:06.3f}")

    def _run_sync(self):
        video_paths = [s.file_path for s in self.sources[:4] if s.file_path]
        if len(video_paths) < 2:
            QMessageBox.warning(self, "Not enough sources", "Upload at least 2 video files before syncing."); return
        self.sync_btn.setEnabled(False); self.goto_label_btn.setEnabled(False)
        self.sync_progress.setVisible(True); self.sync_progress.setValue(0)
        self._set_sync_status("INITIALISING…", "#637DFF")
        eeg_paths = [s.file_path for s in self.sources[4:] if s.file_path]
        self._worker = MainEditorSyncWorker(video_paths, eeg_paths=eeg_paths, parent=self)
        self._worker.progress.connect(self._on_sync_progress)
        self._worker.finished.connect(self._on_sync_finished)
        self._worker.error.connect(self._on_sync_error)
        self._worker.start()

    def _on_sync_progress(self, pct, msg):
        self.sync_progress.setValue(pct); self._set_sync_status(msg.upper(), "#637DFF")

    def _on_sync_finished(self, video_paths, delays_with_sentinel):
        self.sync_progress.setValue(100)
        n_clips = len(video_paths)
        delays = list(delays_with_sentinel[:n_clips])
        max_norm_delay = float(delays_with_sentinel[n_clips]) if len(delays_with_sentinel) > n_clips else 0.0
        seek_ms_list = [int(delays_with_sentinel[n_clips+1+i]) if len(delays_with_sentinel) > n_clips+1+i else 0 for i in range(n_clips)]
        self._temp_paths = video_paths; self._delays = delays; self._residuals_ms = seek_ms_list

        from sync_engine import SourceOffset, SyncResult as _SR
        video_sources = [s for s in self.sources[:4] if s.file_path]
        video_offsets = [SourceOffset(source_id=f"VIDEO_{i+1:02d}", path=src.file_path, offset_sec=delays[i] if i < len(delays) else 0.0, is_reference=(delays[i] == 0.0 if i < len(delays) else True), method="xcorr", confidence=1.0) for i, src in enumerate(video_sources)]
        eeg_sources = [s for s in self.sources[4:] if s.file_path]
        eeg_offsets = [SourceOffset(source_id=f"EEG_{i+1:02d}", path=s.file_path, offset_sec=0.0, method="creation_time", confidence=0.95) for i, s in enumerate(eeg_sources)]
        global_duration = 0.0
        for i, path in enumerate(video_paths):
            if path and os.path.exists(path):
                try:
                    import ffmpeg as _ffmpeg; probe = _ffmpeg.probe(path)
                    d = float(probe["format"].get("duration", 0.0))
                    seek_s = seek_ms_list[i] / 1000.0 if i < len(seek_ms_list) else 0.0
                    content_dur = max(d - seek_s, 0.0)
                    global_duration = content_dur if global_duration == 0.0 else min(global_duration, content_dur)
                except Exception: pass
        self.sync_result = _SR(global_duration=max(global_duration, 0.0), video_offsets=video_offsets, eeg_offsets=eeg_offsets)

        target_seeks = [_clamp_ms(s) for s in seek_ms_list]
        for i, path in enumerate(video_paths):
            p = self.media_players[i] if i < len(self.media_players) else None
            if p and path:
                _pinst = getattr(p, '_vlc_instance_ref', None)
                media = (_pinst.media_new if _pinst else vlc.Media)(Path(path).as_uri())
                p.set_media(media); p.play()

        _poll_count = [0]
        def _wait_and_seek():
            _poll_count[0] += 1
            active = [p for p in self.media_players if p]
            if not all(p.get_length() > 0 for p in active) and _poll_count[0] < 100:
                QTimer.singleShot(100, _wait_and_seek); return
            for i, p in enumerate(self.media_players):
                if p:
                    seek = target_seeks[i] if i < len(target_seeks) else 0
                    p.pause(); p.set_time(seek); print(f"  player {i}: set_time({seek}ms)")
            # Global usable duration = min(clip_length - seek) across all players
            min_usable_ms = 0
            for i, p in enumerate(self.media_players):
                if p and p.get_length() > 0:
                    seek = target_seeks[i] if i < len(target_seeks) else 0
                    usable = p.get_length() - seek
                    if usable > 0:
                        min_usable_ms = usable if min_usable_ms == 0 else min(min_usable_ms, usable)
            if min_usable_ms > 0:
                self.time_slider.setRange(0, _clamp_ms(min_usable_ms))
                self.time_slider.setValue(0)
                secs = min_usable_ms / 1000.0; h = int(secs//3600); m = int((secs%3600)//60); s = secs%60
                self.duration_label.setText(f"{h:02d}:{m:02d}:{s:05.2f}")
            else:
                self.time_slider.setRange(0, 0)
        QTimer.singleShot(200, _wait_and_seek)

        self.time_slider.setRange(0, 0); self.time_slider.setValue(0)
        self.play_btn.setText("▶  PLAY"); self.play_btn.setEnabled(True); self._post_sync_offsets_ms = [0]*4
        for i, (src_row, delay) in enumerate(zip(self.sources[:4], delays)): src_row.set_offset(delay)
        eeg_sources = [s for s in self.sources[4:] if s.file_path]
        for i, widget in enumerate([self.eeg_review_1, self.eeg_review_2]):
            if i < len(eeg_sources):
                try: df = pd.read_csv(eeg_sources[i].file_path); widget.load(df, offset_sec=0.0)
                except Exception as e: print(f"EEG {i+1} error: {e}")
        self._set_sync_status("SYNC COMPLETE  ✓", "#22c55e"); self.sync_btn.setEnabled(True); self.goto_label_btn.setEnabled(True)
        print(f"\nSync offsets (seek per player): {seek_ms_list} ms")

    def _on_sync_error(self, msg):
        self.sync_progress.setValue(0); self._set_sync_status(f"ERROR: {msg[:60]}", "#ef4444")
        self.sync_btn.setEnabled(True); QMessageBox.critical(self, "Sync failed", msg)

    def _set_sync_status(self, text, color):
        self.sync_status.setText(text)
        self.sync_status.setStyleSheet(f"color: {color}; font-size: 10px; font-family: 'Inter'; letter-spacing: 2px; padding: 8px 0;")

    def _export_synced_data(self):
        from PyQt6.QtWidgets import QInputDialog
        if not self.sync_result: QMessageBox.warning(self, "No sync data", "Run AUTO-SYNC before exporting."); return
        zip_name, ok = QInputDialog.getText(self, "Export", "Name this export:", text="Brain_Battle_Session")
        if not ok or not zip_name.strip(): return
        zip_name = zip_name.strip().replace(" ", "_")
        if not zip_name.endswith(".zip"): zip_name += ".zip"
        save_path, _ = QFileDialog.getSaveFileName(self, "Save", zip_name, "ZIP (*.zip)")
        if not save_path: return
        video_paths = [s.file_path or "" for s in self.sources[:4]]
        offset_secs = [self.sync_result.video_offsets[i].offset_sec if i < len(self.sync_result.video_offsets) else 0.0 for i in range(4)]
        eeg_paths = [s.file_path or "" for s in self.sources[4:]]
        sync_rows = [{"source": o.source_id, "offset_sec": o.offset_sec, "method": o.method, "confidence": round(o.confidence,3), "is_reference": o.is_reference} for o in self.sync_result.all_offsets()]
        worker = FullSessionExportWorker(zip_path=save_path, zip_name=zip_name, video_paths=video_paths, offset_secs=offset_secs, eeg_paths=eeg_paths, labels=[], sync_offsets_rows=sync_rows, global_duration=self.sync_result.global_duration, merge_video=True, parent=self)
        ExportProgressDialog(worker, parent=self).exec()

    def _request_label_tab(self):
        parent = self.parent()
        while parent and not isinstance(parent, QTabWidget): parent = parent.parent()
        if not parent: return
        parent.setCurrentIndex(2); label_tab = parent.widget(2)
        if not self.sync_result or not hasattr(label_tab, "load_session_data"): return
        video_data = [(s.file_path, self.sync_result.video_offsets[i].offset_sec if i < len(self.sync_result.video_offsets) else 0.0) for i, s in enumerate(self.sources[:4])]
        eeg_data = []
        for i, s in enumerate(self.sources[4:]):
            if s.file_path:
                try: df = pd.read_csv(s.file_path); off = self.sync_result.eeg_offsets[i].offset_sec if i < len(self.sync_result.eeg_offsets) else 0.0; eeg_data.append((df, off))
                except Exception: eeg_data.append((None, 0.0))
            else: eeg_data.append((None, 0.0))
        label_tab.load_session_data(video_data, eeg_data, self.sync_result)

    def load_session_folder(self, session_root: str, round_num: int = 1) -> None:
        """
        Auto-populate the review tab from a Brain Battle <timestamp>/ folder.

        Called by LiveSessionTab when a capture session finishes, so the
        operator can jump straight from LIVE MONITOR → SYNC + REVIEW without
        re-picking every file. Defaults to loading Round 1; operator can still
        manually pick other rounds via the UPLOAD buttons.

        Mapping (matches SourceRow definitions above):
            0-1 DSLR      ← Side Cams/*.mp4   (slot_index 1, 2)
            2-3 POV       ← POV  Cams/*.mp4   (slot_index 3, 4)
            4-5 MUSE-S    ← Muse data/*.csv   (first two CSVs, alphabetical)
        """
        from pathlib import Path as _Path
        root = _Path(session_root)
        round_folder = root / f"Round {round_num}"
        if not round_folder.is_dir():
            return  # Session may have been stopped before this round began.

        def _sorted(glob_pat):
            return sorted([p for p in round_folder.glob(glob_pat) if p.is_file()])

        side_cams = _sorted("Side Cams/*.mp4") + _sorted("Side Cams/*.MP4")
        pov_cams  = _sorted("POV Cams/*.mp4")  + _sorted("POV Cams/*.MP4")
        muse_csvs = _sorted("Muse data/*.csv") + _sorted("Muse data/*.CSV")

        # Assign each discovered file into the matching SourceRow. Silently
        # skip slots with no corresponding file — operator can upload manually.
        for i, path in enumerate(side_cams[:2]):
            self.sources[i].set_path(str(path))
        for i, path in enumerate(pov_cams[:2]):
            self.sources[2 + i].set_path(str(path))
        for i, path in enumerate(muse_csvs[:2]):
            self.sources[4 + i].set_path(str(path))

        found = len(side_cams[:2]) + len(pov_cams[:2]) + len(muse_csvs[:2])
        if found:
            self.sync_status.setText(
                f"LOADED  {found} FILES  FROM  {root.name} / ROUND {round_num}"
            )
            self.sync_status.setStyleSheet(
                "color: #637DFF; font-size: 10px; font-family: 'Inter'; "
                "letter-spacing: 2px; padding: 8px 0;"
            )


class LabelChip(QWidget):
    clicked = pyqtSignal(str)
    def __init__(self, label_name, color, parent=None):
        super().__init__(parent); self.label_name = label_name; self._name = label_name; self.color = color
        layout = QHBoxLayout(self); layout.setContentsMargins(0,2,0,2)
        btn = QPushButton(label_name); btn.setFixedHeight(28)
        btn.setStyleSheet(f"background-color: transparent; border: 1px solid {color}; color: {color}; font-family: 'Inter'; font-size: 11px; letter-spacing: 1px; padding: 0 10px; text-align: left;")
        btn.clicked.connect(lambda: self.clicked.emit(self.label_name)); layout.addWidget(btn)


class LabelMarker(QWidget):
    removed = pyqtSignal()
    def __init__(self, label_name, color, timestamp_str, parent=None):
        super().__init__(parent); self.label_name = label_name; self.timestamp_str = timestamp_str; self._color = color
        self.setStyleSheet("background-color: #0E0E12;")
        layout = QHBoxLayout(self); layout.setContentsMargins(8,5,8,5); layout.setSpacing(10)
        dot = QLabel("▶"); dot.setFixedWidth(12); dot.setStyleSheet(f"color: {color}; font-size: 9px; border: none;")
        ts = QLabel(timestamp_str); ts.setFixedWidth(88); ts.setStyleSheet("color: #A1A1AA; font-size: 10px; font-family: 'Inter'; border: none;")
        name = QLabel(label_name); name.setStyleSheet(f"color: {color}; font-size: 10px; font-family: 'Inter'; letter-spacing: 1px; border: none;")
        name.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        remove = QPushButton("×"); remove.setFixedSize(20,20)
        remove.setStyleSheet("background: transparent; border: none; color: #A1A1AA; font-size: 14px; padding: 0;")
        remove.clicked.connect(self._remove)
        layout.addWidget(dot); layout.addWidget(ts); layout.addWidget(name); layout.addWidget(remove)
    def _remove(self): self.removed.emit(); self.deleteLater()


class LabellingTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent); self._fake_ts = 0.0
        self._build()
        self._install_shortcuts()
        self._apply_theme()
        import design_tokens as _dt
        _dt.on_theme_change(self._apply_theme)

    def _apply_theme(self):
        """Re-apply theme-reactive styles to the labelling tab's surfaces."""
        import design_tokens as _dt
        self.setStyleSheet(f"LabellingTab {{ background: {_dt.canvas_bg()}; }}")
        for w in self.findChildren(QWidget):
            ss = w.styleSheet()
            if not ss: continue
            new_ss = (ss
                .replace("background-color: #0E0E12", f"background-color: {_dt.canvas_bg()}")
                .replace("background: #0E0E12", f"background: {_dt.canvas_bg()}")
                .replace("background-color: #000", f"background-color: {_dt.canvas_bg()}")
                .replace("background: #000", f"background: {_dt.canvas_bg()}")
                .replace("background-color: #050506", f"background-color: {_dt.canvas_bg()}")
                .replace("background-color: #1C1C21", f"background-color: {_dt.card_bg()}")
                .replace("background: #1C1C21", f"background: {_dt.card_bg()}")
                .replace("background-color: #1F2538", f"background-color: {_dt.accent_ghost()}")
                .replace("background:#1F2538", f"background:{_dt.accent_ghost()}")
                .replace("border: 1px solid #2A2A30", f"border: 1px solid {_dt.border_strong()}")
                .replace("border-bottom: 1px solid #2A2A30", f"border-bottom: 1px solid {_dt.border_strong()}")
                .replace("border-top: 1px solid #2A2A30", f"border-top: 1px solid {_dt.border_strong()}")
                .replace("border-right: 1px solid #2A2A30", f"border-right: 1px solid {_dt.border_strong()}")
                .replace("border: 1px solid #637DFF", f"border: 1px solid {_dt.accent()}")
                .replace("border:1px solid #637DFF", f"border:1px solid {_dt.accent()}")
                .replace("color: #2A2A30", f"color: {_dt.text_tertiary()}")
                .replace("color: #71717A", f"color: {_dt.text_tertiary()}")
                .replace("color: #A1A1AA", f"color: {_dt.text_secondary()}")
                .replace("color: #ECEDEE", f"color: {_dt.text_primary()}")
                .replace("color: #637DFF", f"color: {_dt.accent()}")
                .replace("color:#637DFF", f"color:{_dt.accent()}")
            )
            if new_ss != ss:
                w.setStyleSheet(new_ss)
        for w in self.findChildren(QWidget):
            try:
                s = w.style(); s.unpolish(w); s.polish(w); w.update()
            except Exception: pass

    def _build(self):
        root = QVBoxLayout(self); root.setContentsMargins(0,0,0,0); root.setSpacing(0)
        toolbar = QWidget(); toolbar.setFixedHeight(44)
        toolbar.setStyleSheet("background-color: #0E0E12; border-bottom: 1px solid #2A2A30;")
        tb = QHBoxLayout(toolbar); tb.setContentsMargins(16,0,16,0); tb.setSpacing(8)
        tb.addWidget(make_panel_title("EVENT LABELLING")); tb.addStretch()
        self.export_csv_btn = QPushButton("EXPORT LABELS CSV"); self.export_csv_btn.setFixedHeight(28)
        self.export_csv_btn.setStyleSheet("background-color: #1F2538; border: 1px solid #637DFF; color: #637DFF; font-family: 'Inter'; font-size: 10px; letter-spacing: 2px; padding: 0 14px;")
        tb.addWidget(self.export_csv_btn); root.addWidget(toolbar)
        body = QHBoxLayout(); body.setContentsMargins(0,0,0,0); body.setSpacing(0)

        # LEFT RAIL — 400px wide, mirrors Sync + Review structure:
        # top: DATA SOURCES (upload rows) + LABEL PALETTE
        # bottom: PLACED LABELS list
        left = QWidget(); left.setFixedWidth(400)
        left.setStyleSheet("background-color: #0E0E12; border-right: 1px solid #2A2A30;")
        left_outer = QVBoxLayout(left); left_outer.setContentsMargins(0,0,0,0); left_outer.setSpacing(0)

        # --- DATA SOURCES (uploads) — mirrors SyncReviewTab ---------------------
        sources_panel = QWidget()
        sources_panel.setStyleSheet("background-color: #0E0E12;")
        sources_layout = QVBoxLayout(sources_panel)
        sources_layout.setContentsMargins(10, 14, 10, 10); sources_layout.setSpacing(6)
        sources_layout.addWidget(make_source_label("DATA SOURCES"))
        sources_layout.addSpacing(2)
        # Column headers
        header = QHBoxLayout(); header.setSpacing(6)
        for txt, w in [("", 14), ("TYPE", 100), ("FILE", 0), ("", 72)]:
            h = QLabel(txt); h.setStyleSheet("color: #2A2A30; font-size: 9px; font-family: 'Inter'; letter-spacing: 2px;")
            if w: h.setFixedWidth(w)
            else: h.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            header.addWidget(h)
        sources_layout.addLayout(header); sources_layout.addWidget(make_divider())
        # Upload rows: 4 video slots + 2 Muse-S CSVs (matches Sync tab)
        self.label_sources = []
        label_source_defs = [
            ("DSLR  01", "Video Files (*.mp4 *.mov *.avi *.MP4 *.MOV)"),
            ("DSLR  02", "Video Files (*.mp4 *.mov *.avi *.MP4 *.MOV)"),
            ("POV     01", "Video Files (*.mp4 *.mov *.avi *.MP4 *.MOV)"),
            ("POV     02", "Video Files (*.mp4 *.mov *.avi *.MP4 *.MOV)"),
            ("MUSE-S  01", "CSV Files (*.csv)"),
            ("MUSE-S  02", "CSV Files (*.csv)"),
        ]
        for i, (lbl, filt) in enumerate(label_source_defs):
            row = SourceRow(i, lbl, filt)
            sources_layout.addWidget(row)
            if i == 3: sources_layout.addWidget(make_divider())
            self.label_sources.append(row)
            row.file_loaded.connect(self._on_label_source_loaded)
        sources_layout.addWidget(make_divider())
        left_outer.addWidget(sources_panel)

        # --- LABEL PALETTE -------------------------------------------------------
        palette_header = QWidget(); palette_header.setFixedHeight(36)
        palette_header.setStyleSheet("background-color: #0E0E12; border-top: 1px solid #2A2A30; border-bottom: 1px solid #2A2A30;")
        ph = QHBoxLayout(palette_header); ph.setContentsMargins(14,0,12,0); ph.setSpacing(6)
        ph.addWidget(make_source_label("LABEL PALETTE")); ph.addStretch()
        left_outer.addWidget(palette_header)
        self.active_label_display = QLabel("NO LABEL SELECTED"); self.active_label_display.setFixedHeight(28)
        self.active_label_display.setStyleSheet("color: #71717A; font-size: 10px; font-family: 'Inter'; padding: 0 14px; background: #0E0E12; border-bottom: 1px solid #2A2A30;")
        left_outer.addWidget(self.active_label_display)

        chip_scroll = QScrollArea(); chip_scroll.setWidgetResizable(True)
        chip_scroll.setStyleSheet("border: none; background: #0E0E12;")
        chip_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        chip_scroll.setMinimumHeight(140)
        self._palette_widget = QWidget(); self._palette_widget.setStyleSheet("background: #0E0E12;")
        self._palette_layout = QVBoxLayout(self._palette_widget); self._palette_layout.setContentsMargins(12,6,12,6)
        self._palette_layout.setSpacing(3); self._palette_layout.addStretch()
        chip_scroll.setWidget(self._palette_widget); left_outer.addWidget(chip_scroll, 1)

        add_bar = QWidget(); add_bar.setFixedHeight(36)
        add_bar.setStyleSheet("background-color: #0E0E12; border-top: 1px solid #2A2A30;")
        ab = QHBoxLayout(add_bar); ab.setContentsMargins(12,4,12,4); ab.setSpacing(6)
        self.custom_input = QLineEdit(); self.custom_input.setPlaceholderText("add label…")
        self.custom_input.setStyleSheet("background: #1C1C21; border: 1px solid #2A2A30; color: #ECEDEE; font-family: 'Inter'; font-size: 11px; padding: 0 8px;")
        add_btn = QPushButton("+"); add_btn.setFixedSize(28,26)
        add_btn.setStyleSheet("background:#1F2538; border:1px solid #637DFF; color:#637DFF; font-size:16px; padding:0;")
        ab.addWidget(self.custom_input); ab.addWidget(add_btn)
        left_outer.addWidget(add_bar)
        self.active_label = None; self.active_color = "#637DFF"
        for name, color in PREDEFINED_LABELS: self._add_chip_to_palette(name, color)
        add_btn.clicked.connect(self._add_custom_label); self.custom_input.returnPressed.connect(self._add_custom_label)

        # --- PLACED LABELS -------------------------------------------------------
        placed_header = QWidget(); placed_header.setFixedHeight(36)
        placed_header.setStyleSheet("background-color: #0E0E12; border-top: 1px solid #2A2A30; border-bottom: 1px solid #2A2A30;")
        rh = QHBoxLayout(placed_header); rh.setContentsMargins(14,0,14,0)
        rh.addWidget(make_source_label("PLACED LABELS")); rh.addStretch()
        self.label_count = QLabel("0")
        self.label_count.setStyleSheet("color: #637DFF; font-size: 10px; font-family: 'Inter';")
        rh.addWidget(self.label_count)
        left_outer.addWidget(placed_header)

        scroll = QScrollArea(); scroll.setWidgetResizable(True)
        scroll.setStyleSheet("border: none; background-color: #0E0E12;")
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setMinimumHeight(140)
        self.label_list_widget = QWidget(); self.label_list_widget.setStyleSheet("background-color: #0E0E12;")
        self.placed_layout = QVBoxLayout(self.label_list_widget)
        self.placed_layout.setContentsMargins(0,4,0,4); self.placed_layout.setSpacing(0)
        self.placed_layout.addStretch()
        scroll.setWidget(self.label_list_widget); left_outer.addWidget(scroll, 1)

        body.addWidget(left)

        # === RIGHT AREA — scrollable, mirrors Sync tab =============================
        right_scroll = QScrollArea(); right_scroll.setWidgetResizable(True)
        right_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        right_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        right_scroll.setStyleSheet(
            "QScrollArea { background: #0E0E12; border: none; } "
            "QScrollBar:vertical { background: #0E0E12; width: 8px; border: none; } "
            "QScrollBar::handle:vertical { background: #2A2A30; border-radius: 4px; min-height: 24px; } "
            "QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; border: none; }"
        )
        center = QWidget(); center.setStyleSheet("background-color: #0E0E12;")
        center.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        center_layout = QVBoxLayout(center); center_layout.setContentsMargins(0,0,0,0); center_layout.setSpacing(0)

        # Video grid (2x2) — uses _AspectVideoArea to size proportionally to width
        class _LabelVideoArea(QWidget):
            HEADER_H = 26; SPACING = 2
            def resizeEvent(self, event):
                super().resizeEvent(event)
                cell_w = max(100, (self.width() - self.SPACING - 24) // 2)
                cell_h = int(cell_w * 9 / 16)
                self.setFixedHeight((cell_h + self.HEADER_H) * 2 + self.SPACING + 40)

        video_area = _LabelVideoArea()
        video_area.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        video_area.setStyleSheet("background-color: #0E0E12;")
        va = QVBoxLayout(video_area); va.setContentsMargins(12,12,12,8); va.setSpacing(6)
        va.addWidget(make_source_label("SYNCHRONIZED PLAYBACK"))
        vg = QGridLayout(); vg.setSpacing(6)
        vg.setRowStretch(0,1); vg.setRowStretch(1,1)
        vg.setColumnStretch(0,1); vg.setColumnStretch(1,1)
        self.label_slots = []
        for i, ln in enumerate(["DSLR","DSLR","POV","POV"]):
            sl = VLCVideoSlot(i+1, label=ln)
            vg.addWidget(sl, *divmod(i,2))
            self.label_slots.append(sl)
        self._label_sync_ctrl = SyncPlaybackController()
        va.addLayout(vg, 1)
        center_layout.addWidget(video_area)

        # EEG overlay below — fixed minimum so it's always legible
        eeg_strip = QWidget()
        eeg_strip.setMinimumHeight(220); eeg_strip.setMaximumHeight(280)
        eeg_strip.setStyleSheet("background-color: #0E0E12;")
        eeg_strip_layout = QVBoxLayout(eeg_strip)
        eeg_strip_layout.setContentsMargins(12,6,12,6); eeg_strip_layout.setSpacing(4)
        eeg_strip_layout.addWidget(make_source_label("EEG OVERLAY"))
        eeg_strip_row = QHBoxLayout(); eeg_strip_row.setSpacing(6)
        self.eeg_label_1 = EEGReviewWidget(channel_id=1); self.eeg_label_2 = EEGReviewWidget(channel_id=2)
        eeg_strip_row.addWidget(self.eeg_label_1); eeg_strip_row.addWidget(self.eeg_label_2)
        eeg_strip_layout.addLayout(eeg_strip_row, 1)
        center_layout.addWidget(eeg_strip)

        # Timeline + transport — fixed at bottom
        tl_container = QWidget(); tl_container.setFixedHeight(100)
        tl_container.setStyleSheet("background-color: #0E0E12; border-top: 1px solid #2A2A30;")
        tl_layout = QVBoxLayout(tl_container); tl_layout.setContentsMargins(16,8,16,8); tl_layout.setSpacing(6)
        tl_header = QHBoxLayout(); tl_header.addWidget(make_source_label("TIMELINE")); tl_header.addStretch()
        self.tl_tc = QLabel("00:00:00.000"); self.tl_tc.setObjectName("timecode"); tl_header.addWidget(self.tl_tc)
        tl_layout.addLayout(tl_header)
        self.tl_slider = QSlider(Qt.Orientation.Horizontal); self.tl_slider.setRange(0,10000); self.tl_slider.setValue(0)
        self.tl_slider.valueChanged.connect(self._on_timeline_scrub); tl_layout.addWidget(self.tl_slider)
        play_row = QHBoxLayout(); play_row.setSpacing(8)
        rewind_btn = QPushButton("⏮"); rewind_btn.setFixedSize(32,28)
        rewind_btn.setStyleSheet("background-color: #1C1C21; border: 1px solid #2A2A30; color: #ECEDEE; font-size: 12px; padding: 0;")
        rewind_btn.clicked.connect(lambda: self._label_sync_ctrl.seek(0.0)); play_row.addWidget(rewind_btn)
        self._play_btn_lbl = QPushButton("▶  PLAY"); self._play_btn_lbl.setFixedWidth(110); self._play_btn_lbl.setFixedHeight(28)
        self._play_btn_lbl.setEnabled(False)
        self._play_btn_lbl.setStyleSheet("background-color: #1C1C21; border: 1px solid #2A2A30; color: #ECEDEE; font-size: 12px; padding: 0;")
        self._play_btn_lbl.clicked.connect(self._toggle_play_label); play_row.addWidget(self._play_btn_lbl)
        skip_btn = QPushButton("⏭"); skip_btn.setFixedSize(32,28)
        skip_btn.setStyleSheet("background-color: #1C1C21; border: 1px solid #2A2A30; color: #ECEDEE; font-size: 12px; padding: 0;")
        play_row.addWidget(skip_btn)
        self._label_pos_timer = QTimer(self); self._label_pos_timer.setInterval(100)
        self._label_pos_timer.timeout.connect(self._update_label_timeline)
        place_btn = QPushButton("PLACE LABEL AT PLAYHEAD"); place_btn.setFixedHeight(28)
        place_btn.setStyleSheet("background-color: #1F2538; border: 1px solid #637DFF; color: #637DFF; font-family: 'Inter'; font-size: 9px; letter-spacing: 2px; padding: 0 14px;")
        place_btn.clicked.connect(self._place_label); play_row.addWidget(place_btn); play_row.addStretch()
        self._end_lbl = QLabel("--:--:--.---")
        self._end_lbl.setStyleSheet("color: #A1A1AA; font-size: 11px; font-family: 'Inter'; letter-spacing: 1px;")
        play_row.addWidget(self._end_lbl); tl_layout.addLayout(play_row)
        center_layout.addWidget(tl_container)

        right_scroll.setWidget(center)
        body.addWidget(right_scroll, 1)

        root.addLayout(body)
        self.export_csv_btn.clicked.connect(self._export_labels); QTimer.singleShot(0, self._do_recount)

    def _on_label_source_loaded(self, source_id: int, path: str):
        """Route uploaded file to the correct video slot or EEG widget.
        source_ids 0-3 are DSLR/POV videos, 4-5 are Muse-S CSVs."""
        if source_id < 4:
            slot = self.label_slots[source_id]
            try:
                slot.load(path, offset_sec=0.0)
            except Exception as e:
                print(f"[label load] video {source_id}: {e}")
            self._play_btn_lbl.setEnabled(True)
        elif source_id == 4:
            self._load_label_eeg_async(path, self.eeg_label_1)
        elif source_id == 5:
            self._load_label_eeg_async(path, self.eeg_label_2)

    def _load_label_eeg_async(self, path: str, widget):
        """Load EEG CSV for label tab — mirrors SyncReviewTab._load_eeg_async."""
        class _LabelEEGLoader(QThread):
            done = pyqtSignal(object)
            def __init__(self, p, parent=None):
                super().__init__(parent); self._p = p
            def run(self):
                try:
                    df = pd.read_csv(self._p)
                    col_map = {c.lower(): c for c in df.columns}
                    if 'timestamps' not in df.columns and 'timestamps' in col_map:
                        df = df.rename(columns={col_map['timestamps']: 'timestamps'})
                    self.done.emit(df)
                except Exception as e:
                    print(f"[label EEG load error] {e}")
        loader = _LabelEEGLoader(path, parent=self)
        if not hasattr(self, '_label_eeg_loaders'):
            self._label_eeg_loaders = []
        self._label_eeg_loaders.append(loader)
        def _on_done(df, _w=widget, _l=loader):
            try: _w.load(df, offset_sec=0.0)
            except Exception as e:
                import traceback; traceback.print_exc()
            finally:
                try: _l.wait(2000)
                except Exception: pass
                if _l in self._label_eeg_loaders:
                    self._label_eeg_loaders.remove(_l)
        loader.done.connect(_on_done)
        loader.start()

    def _add_chip_to_palette(self, name, color):
        row = QWidget(); row.setStyleSheet("background: transparent;")
        rl = QHBoxLayout(row); rl.setContentsMargins(0,1,0,1); rl.setSpacing(4)
        chip = LabelChip(name, color); chip.clicked.connect(self._select_label); rl.addWidget(chip)
        # Keyboard shortcut hint — first 9 palette chips get 1-9 binding
        slot_idx = self._palette_layout.count() - 1  # before the stretch
        if 0 <= slot_idx < 9:
            import design_tokens as _dt
            key_lbl = QLabel(str(slot_idx + 1))
            key_lbl.setFixedSize(20, 20)
            key_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            key_lbl.setStyleSheet(
                f"background: {_dt.card_bg()}; border: 1px solid {_dt.border_strong()}; "
                f"border-radius: 4px; color: {_dt.text_secondary()}; "
                f"font-family: {_dt.FONT_MONO}; font-size: 10px; font-weight: 600;"
            )
            rl.addWidget(key_lbl)
        rm = QPushButton("×"); rm.setFixedSize(22,24)
        rm.setStyleSheet("background: transparent; border: none; color: #A1A1AA; font-size: 14px; padding: 0;")
        rm.clicked.connect(lambda checked, r=row, n=name: self._remove_chip(r, n)); rl.addWidget(rm)
        self._palette_layout.insertWidget(self._palette_layout.count()-1, row)

    def _install_shortcuts(self):
        """Keyboard shortcuts for real-time labelling workflow.
        Number keys 1-9 select + place labels. Space toggles play/pause."""
        from PyQt6.QtGui import QShortcut, QKeySequence
        for i in range(9):
            sc = QShortcut(QKeySequence(str(i + 1)), self)
            sc.activated.connect(lambda idx=i: self._shortcut_place(idx))
        sc_play = QShortcut(QKeySequence("Space"), self)
        sc_play.activated.connect(self._toggle_play_label)

    def _shortcut_place(self, idx):
        """Select palette chip #idx and place label at current playhead."""
        # Walk the palette to find the idx-th chip
        palette_row = None; n = 0
        for i in range(self._palette_layout.count() - 1):
            item = self._palette_layout.itemAt(i)
            if item and item.widget():
                chips = item.widget().findChildren(LabelChip)
                if chips:
                    if n == idx:
                        palette_row = chips[0]; break
                    n += 1
        if palette_row is None: return
        self._select_label(palette_row._name, palette_row.color)
        self._place_label()

    def _remove_chip(self, row, name):
        row.deleteLater()
        if self.active_label == name:
            self.active_label = None; self.active_color = "#637DFF"; self.active_label_display.setText("NO LABEL SELECTED")
            self.active_label_display.setStyleSheet("color: #71717A; font-size: 10px; font-family: 'Inter'; padding: 0 12px; background: #0E0E12; border-bottom: 1px solid #2A2A30;")
        QTimer.singleShot(50, lambda: save_labels(self._current_labels()))

    def _current_labels(self):
        labels = []
        for i in range(self._palette_layout.count()-1):
            item = self._palette_layout.itemAt(i)
            if item and item.widget():
                chips = item.widget().findChildren(LabelChip)
                if chips: labels.append((chips[0]._name, chips[0].color))
        return labels

    def _add_custom_label(self):
        name = self.custom_input.text().strip().upper().replace(" ","_")
        if not name: return
        existing = set()
        for i in range(self._palette_layout.count()-1):
            item = self._palette_layout.itemAt(i)
            if item and item.widget():
                children = item.widget().findChildren(LabelChip)
                if children: existing.add(children[0]._name)
        if name in existing: self._select_label(name); self.custom_input.clear(); return
        color = next_colour(self._current_labels()); self._add_chip_to_palette(name, color)
        self.custom_input.clear(); self._select_label(name); save_labels(self._current_labels())

    def _select_label(self, name):
        self.active_label = name; color = "#637DFF"
        for i in range(self._palette_layout.count()-1):
            item = self._palette_layout.itemAt(i)
            if item and item.widget():
                chips = item.widget().findChildren(LabelChip)
                if chips and chips[0]._name == name: color = chips[0].color; break
        self.active_color = color; self.active_label_display.setText(f"● {name}")
        self.active_label_display.setStyleSheet(f"color: {color}; font-size: 11px; font-family: 'Inter'; padding: 0 12px; background: #0E0E12; border-bottom: 1px solid {color};")

    def _toggle_play_label(self):
        if self._label_sync_ctrl.is_playing():
            self._label_sync_ctrl.pause(); self._play_btn_lbl.setText("▶  PLAY"); self._label_pos_timer.stop()
        else:
            self._label_sync_ctrl.play(); self._play_btn_lbl.setText("⏸  PAUSE"); self._label_pos_timer.start()

    def _update_label_timeline(self):
        global_t = self._label_sync_ctrl.current_global_t(); self._fake_ts = global_t
        h = int(global_t//3600); m = int((global_t%3600)//60); s = global_t%60
        self.tl_tc.setText(f"{h:02d}:{m:02d}:{s:06.3f}")
        loaded = [sl for sl in self.label_slots if sl.is_loaded()]
        dur = (loaded[0].get_duration_sec() if loaded else 1.0) or 1.0
        self.tl_slider.blockSignals(True); self.tl_slider.setValue(int((global_t/dur)*10000)); self.tl_slider.blockSignals(False)
        self.eeg_label_1.set_playhead(global_t); self.eeg_label_2.set_playhead(global_t)

    def _on_timeline_scrub(self, value):
        loaded = [sl for sl in self.label_slots if sl.is_loaded()]
        dur = (loaded[0].get_duration_sec() if loaded else 1.0) or 1.0
        total_secs = (value/10000)*dur; h = int(total_secs//3600); m = int((total_secs%3600)//60); s = total_secs%60
        self.tl_tc.setText(f"{h:02d}:{m:02d}:{s:06.3f}"); self._fake_ts = total_secs
        self._label_sync_ctrl.seek(total_secs); self.eeg_label_1.set_playhead(total_secs); self.eeg_label_2.set_playhead(total_secs)

    def load_session_data(self, video_slots_data, eeg_data, sync_result):
        for i, (path, offset) in enumerate(video_slots_data):
            if i < len(self.label_slots) and path: self.label_slots[i].load(path, offset_sec=offset)
        loaded = [s for s in self.label_slots if s.is_loaded()]; offsets = [s._offset_sec for s in loaded]
        dur = sync_result.global_duration if sync_result else 0.0
        self._label_sync_ctrl.attach(loaded, offsets_sec=offsets, global_duration=dur)
        if dur > 0:
            h = int(dur//3600); m = int((dur%3600)//60); s = dur%60; self._end_lbl.setText(f"{h:02d}:{m:02d}:{s:06.3f}")
        for i, (df, offset) in enumerate(eeg_data):
            if i == 0 and df is not None: self.eeg_label_1.load(df, offset_sec=offset)
            elif i == 1 and df is not None: self.eeg_label_2.load(df, offset_sec=offset)
        self._play_btn_lbl.setEnabled(True)

    def load_eeg_data(self, df1, offset1, df2, offset2):
        if df1 is not None: self.eeg_label_1.load(df1, offset_sec=offset1)
        if df2 is not None: self.eeg_label_2.load(df2, offset_sec=offset2)

    def _place_label(self):
        if not self.active_label: return
        ts = self._fake_ts; h = int(ts//3600); m = int((ts%3600)//60); s = ts%60
        ts_str = f"{h:02d}:{m:02d}:{s:06.3f}"
        marker = LabelMarker(self.active_label, self.active_color, ts_str)
        marker.removed.connect(self._update_label_count)
        self.placed_layout.insertWidget(self.placed_layout.count()-1, marker); self._update_label_count()

    def _update_label_count(self): QTimer.singleShot(0, self._do_recount)

    def _do_recount(self):
        if not hasattr(self,'placed_layout') or not hasattr(self,'label_count'): return
        n = sum(1 for i in range(self.placed_layout.count()) if isinstance(self.placed_layout.itemAt(i).widget(), LabelMarker))
        self.label_count.setText(str(n))

    def get_labels(self):
        labels = []
        for i in range(self.placed_layout.count()-1):
            item = self.placed_layout.itemAt(i)
            if item and item.widget() and isinstance(item.widget(), LabelMarker):
                marker = item.widget(); ts_str = marker.timestamp_str; name = marker.label_name
                try: parts = ts_str.split(":"); ts_sec = float(parts[0])*3600 + float(parts[1])*60 + float(parts[2])
                except Exception: ts_sec = 0.0
                labels.append({"timestamp_sec": round(ts_sec,3), "timestamp_str": ts_str, "label": name, "color": marker._color})
        return labels

    def _export_labels(self):
        labels = self.get_labels()
        if not labels: QMessageBox.information(self, "No labels", "Place some labels before exporting."); return
        path, _ = QFileDialog.getSaveFileName(self, "Export labels", "labels.csv", "CSV (*.csv)")
        if path:
            try: LabelsExporter.export(labels, path); QMessageBox.information(self, "Exported", f"Saved {len(labels)} labels to:\n{path}")
            except Exception as e: QMessageBox.critical(self, "Export failed", str(e))


class BrainBattleApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Brain Battle")
        self.setMinimumSize(1280, 800); self.resize(1440, 900); self._build()

    def _build(self):
        import design_tokens as dt
        from sidebar_shell import SidebarShell

        self._restyle_app()
        dt.on_theme_change(self._restyle_app)

        central = QWidget(); central.setObjectName("AppRoot")
        self.setCentralWidget(central)
        root = QVBoxLayout(central); root.setContentsMargins(0, 0, 0, 0); root.setSpacing(0)

        # Sidebar shell replaces the old QTabWidget
        self._shell = SidebarShell()
        self.live_tab  = LiveSessionTab()
        self.sync_tab  = SyncReviewTab(); self.sync_tab._app_ref = self
        self.label_tab = LabellingTab()

        self._shell.add_page("activity", "Live Monitor",    self.live_tab)
        self._shell.add_page("layers",   "Sync + Review",   self.sync_tab)
        self._shell.add_page("tag",      "Labelling",       self.label_tab)

        # For LabellingTab compatibility with SyncReviewTab.proceed_to_label_tab()
        # which walks up to find a QTabWidget; we expose .tabs as a shim object
        # with a .setCurrentIndex() method that routes through the shell.
        class _ShellTabShim:
            def __init__(self, shell): self._shell = shell
            def setCurrentIndex(self, idx: int): self._shell.set_current_index(idx)
            def currentIndex(self): return self._shell.current_index()
        self.tabs = _ShellTabShim(self._shell)

        self.live_tab.session_saved.connect(
            lambda path: self.sync_tab.load_session_folder(path, round_num=1)
        )

        root.addWidget(self._shell, 1)

        self._status_bar = QStatusBar()
        self._status_bar.showMessage("6 sources expected  ·  2× DSLR  ·  2× POV  ·  2× Muse-S")
        self.setStatusBar(self._status_bar)
        self._restyle_status()

    def _restyle_app(self):
        """Apply the global stylesheet — called on startup and on theme toggle."""
        from PyQt6.QtWidgets import QApplication
        import design_tokens as dt
        self.setStyleSheet(dt.qss_app() + _supplementary_qss())
        # Walk the entire widget tree and force repolish so every
        # QSS selector with objectName re-evaluates against the new theme.
        stack = [self]
        while stack:
            w = stack.pop()
            if w is None: continue
            try:
                s = w.style()
                s.unpolish(w); s.polish(w); w.update()
            except Exception: pass
            try:
                for child in w.children():
                    if hasattr(child, "style"):
                        stack.append(child)
            except Exception: pass
        if hasattr(self, "_status_bar"):
            self._restyle_status()

    def _restyle_status(self):
        import design_tokens as dt
        self._status_bar.setStyleSheet(
            f"background: {dt.canvas_bg()}; border-top: 1px solid {dt.border()}; "
            f"color: {dt.text_tertiary()}; font-family: {dt.FONT_UI}; font-size: 10px;"
        )


if __name__ == "__main__":
    import traceback as _tb
    import json as _json
    import design_tokens as _dt

    # Load saved theme preference (defaults to dark on first run)
    _pref_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), ".brain_battle_prefs.json"
    )
    try:
        with open(_pref_path, "r") as _f:
            _prefs = _json.load(_f)
            _theme = _prefs.get("theme", "dark")
            if _theme in ("light", "dark"):
                _dt.set_theme(_theme)
    except Exception:
        pass

    app = QApplication(sys.argv); app.setApplicationName("Brain Battle")
    def _excepthook(exc_type, exc_value, exc_tb):
        print("\n=== UNHANDLED EXCEPTION ==="); _tb.print_exception(exc_type, exc_value, exc_tb)
    sys.excepthook = _excepthook
    try:
        window = BrainBattleApp(); window.show()
    except Exception:
        _tb.print_exc(); input("\nPress Enter to exit..."); sys.exit(1)
    def _cleanup():
        # Stop EEG streams + camera threads + loader threads before Qt
        # tears down widgets — prevents "QThread destroyed while still
        # running" crash on exit.
        try: window.live_tab.shutdown()
        except Exception: pass
        try: window.sync_tab.shutdown()
        except Exception: pass
    app.aboutToQuit.connect(_cleanup)
    sys.exit(app.exec())